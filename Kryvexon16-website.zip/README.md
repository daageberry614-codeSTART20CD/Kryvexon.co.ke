# Kryvexon16 Demo Website

A responsive static dashboard branded as Kryvexon16, inspired by the reference screenshots supplied by the user. The figures and plans are illustrative interface examples only. No login, deposits, withdrawals, or real earnings are implemented.

## Publish with GitHub Pages
1. Sign in to GitHub and create a repository (for example, `kryvexon16`).
2. Upload `index.html` and the complete `assets` folder from this ZIP.
3. Open **Settings → Pages**.
4. Under Build and deployment, select **Deploy from a branch**, choose `main` and `/(root)`, then Save.
5. Wait for GitHub to show the published Pages URL in Settings → Pages.

This is a static demo. Do not use it to collect payments or personal data. A real payment system needs a secure backend and verified payment-provider integration.
